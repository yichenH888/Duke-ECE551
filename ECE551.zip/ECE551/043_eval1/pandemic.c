#include "pandemic.h"

#include <ctype.h>
#include <stdio.h>
#include <string.h>

country_t parseLine(char * line) {
  //Print out the name of country and corresponding population
  country_t ans;

  //initialization
  for (int i = 0; i < 64; i++) {
    ans.name[i] = '\0';
  }
  ans.population = 0;

  //detect comma
  char comma = ',';
  char * CommaPopulation = strrchr(line, comma);
  char * compare_comma = strchr(line, comma);
  if (CommaPopulation == NULL) {
    fprintf(stderr, "Error: There is no comma in the line.\n");
    exit(EXIT_FAILURE);
  }

  if (CommaPopulation != compare_comma) {
    fprintf(stderr, "Error: There is more than one comma in the line.\n");
    exit(EXIT_FAILURE);
  }

  //Calculate length of name, detech other character in population(except digits)
  size_t CP_length = 0;
  size_t line_length = 0;
  int flag = 0;
  while (*(CommaPopulation + CP_length) != '\n') {
    if (isdigit(*(CommaPopulation + CP_length)) != 0) {
      flag = 1;  //met a digit
    }

    if (isdigit(*(CommaPopulation + CP_length)) == 0 && flag == 1) {
      fprintf(stderr, "Error: The format of population is incorrect!");
      exit(EXIT_FAILURE);
    }
    CP_length++;
  }
  while (*(line + line_length) != '\n') {
    line_length++;
  }

  size_t Name_length = line_length - CP_length;

  if (Name_length > MAX_NAME_LEN) {
    fprintf(stderr, "Error: The length of country name exceeds the limit!");
    exit(EXIT_FAILURE);
  }
  //Store the country name
  strncpy(ans.name, line, Name_length);
  // Store the population
  ans.population = strtoll(CommaPopulation + 1, NULL, 10);

  return ans;
}

void calcRunningAvg(unsigned * data, size_t n_days, double * avg) {
  //Calculate running average
  double sum = 0;
  double CON = 1;

  if (data == NULL || n_days < 7 || avg == NULL) {
    fprintf(stderr, "Error: The input has some error.\n");
    exit(EXIT_SUCCESS);
  }

  for (size_t i = 0; i < n_days - 6; i++) {
    for (size_t j = 0; j < 7; j++) {
      sum = sum + *(data + i + j) * CON;
    }
    *(avg + i) = sum / 7;
    sum = 0;
  }
}

void calcCumulative(unsigned * data, size_t n_days, uint64_t pop, double * cum) {
  //calculate the cumulative number of cases that day per 100,000 people
  if (data == NULL || cum == NULL || n_days == 0 || pop == 0) {
    fprintf(stderr, "Error: The input has some error");
    exit(EXIT_SUCCESS);
  }
  double cum_sum = 0;
  double CON = 1;
  for (size_t i = 0; i < n_days; i++) {
    cum_sum = *(data + i) * CON + cum_sum;
    *(cum + i) = cum_sum / pop * 100000;
  }
}

void printCountryWithMax(country_t * countries,
                         size_t n_countries,
                         unsigned ** data,
                         size_t n_days) {
  //finds the maximum number of daily cases of all countries represented in the data, over the entire time period

  if (countries == NULL || data == NULL || n_countries == 0 || n_days == 0) {
    fprintf(stderr, "Error: The input has some error");
    exit(EXIT_SUCCESS);
  }
  unsigned max_case = 0;
  unsigned max_case_PerCountry = 0;
  size_t max_index_country = 0;
  size_t max_index_case = 0;
  size_t max_index_case_temp = 0;
  for (size_t i = 0; i < n_countries; i++) {
    for (size_t j = 0; j < n_days; j++) {
      if (data[i][j] > max_case_PerCountry) {
        max_case_PerCountry = data[i][j];
        max_index_case_temp = j;
      }
    }
    if (max_case_PerCountry > max_case) {
      max_case = max_case_PerCountry;
      max_index_country = i;
      max_index_case = max_index_case_temp;
    }
    max_index_case_temp = 0;
  }
  printf("%s has the most daily cases with %u\n",
         countries[max_index_country].name,
         data[max_index_country][max_index_case]);
}
