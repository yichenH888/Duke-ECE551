#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

#include "page.hpp"
using namespace std;
int main(int argc, char ** argv) {
  try {
    if (argc != 2) {
      throw argcNum();
    }
    Story story;
    for (int i = 1; i < argc; i++) {
      story.readStory(argv[i]);
      story.verifyStory(argv[i]);
      story.printOwnStory(argv[i]);
    }
  }
  catch (argcNum & e) {
    errorMsg(e.what());
  }
  catch (referenceInvalid & e) {
    errorMsg(e.what());
  }
  catch (neverReferenced & e) {
    errorMsg(e.what());
  }
  catch (noWinLose & e) {
    errorMsg(e.what());
  }
  return EXIT_SUCCESS;
}
