#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

int freq_max = 0;
int index_max = 0;

void getMax(FILE * f) {
  int character;
  int freq[26] = {0};
  while ((character = fgetc(f)) != EOF) {
    if (isalpha(character)) {
      character = tolower(character);
      character = character - 'a';
      freq[character] = freq[character] + 1;
    }
  }
  int i = 0;
  while (i < 26) {
    if (freq[i] > freq_max) {
      freq_max = freq[i];
      index_max = i;
    }
    i++;
  }
  return;
}
void PRINT() {
  if (freq_max == 0) {
    fprintf(stderr, "Error: The file contains no letter.\n");
    exit(EXIT_FAILURE);
  }
  else if (index_max < 4) {
    fprintf(stdout, "%d\n", index_max + 22);
  }
  else {
    fprintf(stdout, "%d\n", index_max - 4);
  }
  return;
}

int main(int argc, char ** argv) {
  if (argc != 2) {
    fprintf(stderr, "Error: File name\n");
    return EXIT_FAILURE;
  }
  // printf("111");
  FILE * f = fopen(argv[1], "r");
  if (f == NULL) {
    fprintf(stderr, "Error: file == NULL\n");
    return EXIT_FAILURE;
  }
  getMax(f);
  PRINT();
  if (fclose(f) != 0) {
    fprintf(stderr, "Error: Failed to close\n");
    return EXIT_FAILURE;
  }
  return EXIT_SUCCESS;
}
