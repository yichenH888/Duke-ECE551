#include <stdio.h>
#include <stdlib.h>

size_t maxSeq(int * array, size_t n);

void test(int * array, size_t n, size_t e) {
  size_t s = maxSeq(array, n);
  printf("Array: ");
  if (array == NULL) {
    printf("NULL");
  }
  else {
    printf("{");
    for (int i = 0; i < n; i++) {
      printf("%d", array[i]);
      if (i < n - 1) {
        printf(", ");
      }
    }
    printf("}");
  }

  printf("n: %lu, return: %lu\n", n, s);
  if (s != e) {
    printf("Failed! expected: %lu, actual: %lu\n", e, s);
    exit(EXIT_FAILURE);
  }
}

int main(void) {
  int array1[] = {4, 5, 6, 7, 8, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17};
  int array2[] = {19, 20, -89, 21, 22, -30, -29, -28, 37, 39, 40, 41};
  int array3[] = {1, 2, 1, 2, 3, 2, 5, 6, 7, 9, 9, 10, 12, 13, 14, 15};
  size_t n = 4;
  size_t e = 2;
  test(&array1[3], n, e);

  n = 3;
  e = 2;
  test(&array1[3], n, e);

  n = 5;
  e = 5;
  test(array1, n, e);

  n = 9;
  e = 5;
  test(array1, n, e);

  n = 2;
  e = 2;
  test(array2, n, e);

  n = 4;
  e = 2;
  test(array2, n, e);

  n = 2;
  e = 1;
  test(&array2[1], n, e);

  n = 12;
  e = 7;
  test(array2, n, e);

  n = 0;
  e = 0;
  test(array2, n, e);
  test(NULL, n, e);

  n = 16;
  e = 6;
  test(array3, n, e);

  printf("Tests passed!\n");
  return EXIT_SUCCESS;
}
