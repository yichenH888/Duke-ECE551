#include <stdio.h>
#include <stdlib.h>

struct _retire_info {
  int months;
  double contribution;
  double rate_of_return;
};

typedef struct _retire_info retire_info;

double cal_month(double initial_month, double rate_month, double contribution) {
  double benefit = initial_month * rate_month;
  double result = benefit + contribution + initial_month;
  return result;
}

void retirement(int startAge,         //in months
                double initial,       //initial savings in dollars
                retire_info working,  //info about working
                retire_info retired)  //info about being retired
{
  {
    while (working.months > 0) {
      printf(
          "Age %3d month %2d you have $%.2lf\n", startAge / 12, startAge % 12, initial);
      initial = cal_month(initial, working.rate_of_return / 12, working.contribution);
      startAge += 1;
      working.months -= 1;
    }
  }
  {
    while (retired.months > 0) {
      printf(
          "Age %3d month %2d you have $%.2lf\n", startAge / 12, startAge % 12, initial);
      initial = cal_month(initial, retired.rate_of_return / 12, retired.contribution);
      startAge += 1;
      retired.months -= 1;
    }
  }
}

int main() {
  retire_info working;
  working.months = 489;
  working.contribution = 1000;
  working.rate_of_return = 0.045;
  retire_info retired;
  retired.months = 384;
  retired.contribution = -4000;
  retired.rate_of_return = 0.01;
  retirement(327, 21345, working, retired);
  return EXIT_SUCCESS;
}
