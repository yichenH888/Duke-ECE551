#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

void Rotate(FILE * f) {
  char matrix[10][10] = {0};
  char line[12];
  int num_PerLine = 0;
  while ((fgets(line, 12, f)) != NULL) {
    num_PerLine++;

    if (line[10] != '\n') {
      fprintf(stderr, "Error: Number of character per line is not exactly 10.\n");
      exit(EXIT_FAILURE);
    }

    if (num_PerLine > 10) {
      fprintf(stderr, "Error: Number of lines exceeds 10.\n");
      exit(EXIT_FAILURE);
    }
    int i = 0;
    while (i < 10) {
      matrix[i][10 - num_PerLine] = line[i];
      i++;
    }
  }
  if (num_PerLine < 10) {
    fprintf(stderr, "Error: Number of lines is less than 10.\n");
    exit(EXIT_FAILURE);
  }
  for (int j = 0; j < 10; j++) {
    for (int k = 0; k < 10; k++) {
      fprintf(stdout, "%c", matrix[j][k]);
    }
    fprintf(stdout, "\n");
  }
}
int main(int argc, char ** argv) {
  if (argc != 2) {
    fprintf(stderr, "Error: File Name\n");
    return EXIT_FAILURE;
  }
  FILE * f = fopen(argv[1], "r");
  if (f == NULL) {
    fprintf(stderr, "Error: file == NULL\n");
    return EXIT_FAILURE;
  }
  Rotate(f);
  if (fclose(f) != 0) {
    fprintf(stderr, "Error: Failed to close\n");
    return EXIT_FAILURE;
  }
  return EXIT_SUCCESS;
}
