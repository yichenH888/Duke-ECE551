#ifndef __RAND_STORY_H__
#define __RAND_STORY_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "provided.h"

//any functions you want your main to use

struct story_tag {
  size_t line_sz;
  char ** line;
};
typedef struct story_tag story;

//Read in the story template file and store the information in struct story
story * readTemplate(const char * fileName);

//Detect and substitude the blank-single line
char * subBlank(char * line, catarray_t * cate);

//Sub the blank-all the lines
void subStory(story * s, catarray_t * cate);

//Read "words" file
catarray_t * readWords(const char * fileName, int step2);

//Extract and analyze "words" file
catarray_t * processWords(char * line, catarray_t * cate);

//Add one more line to array to atore used words
catarray_t * addUsedCat(catarray_t * cate);

//Choose a suitbale word
const char * decideWord(char * category, catarray_t * cate);

//free struct category_t
void freeCategory(category_t * cat);
#endif
