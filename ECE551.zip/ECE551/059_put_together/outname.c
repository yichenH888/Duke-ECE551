#include "outname.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char * computeOutputFileName(const char * inputName) {
  //WRITE ME
  size_t length = strlen(inputName);
  char * result;
  result = strndup(inputName, length);
  result = realloc(result, (length + 8) * sizeof(*result));
  strcpy(result + length, ".counts\0");
  return result;
}
