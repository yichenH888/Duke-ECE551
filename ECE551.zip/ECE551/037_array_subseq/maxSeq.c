#include <stdio.h>
#include <stdlib.h>

size_t maxSeq(int * array, size_t n) {
  int count = 1;
  int i = 1;
  int count_max = 0;

  if (array == NULL || n == 0) {
    return count_max;
  }
  else if (n == 1) {
    return count;
  }
  else {
    while (i < n) {
      if (array[i - 1] < array[i]) {
        count = count + 1;
        if (i == n - 1 && count > count_max) {
          count_max = count;
        }
      }
      else {
        count = 1;
      }

      if (count_max < count) {
        count_max = count;
      }
      i = i + 1;
    };

    //printf("%d",i);

    //printf("%d", count_max);
    //printf("%d",i);
    return count_max;
  }
}
