#include "rand_story.h"

int main(int argc, char ** argv) {
  if (argc != 2) {
    fprintf(stderr, "Error: argc");
    exit(EXIT_FAILURE);
  }
  story * s = readTemplate(argv[1]);
  subStory(s, NULL);
  for (size_t i = 0; i < s->line_sz; i++) {
    printf("%s", s->line[i]);
    free(s->line[i]);
  }
  free(s->line);
  free(s);
  return EXIT_SUCCESS;
}
