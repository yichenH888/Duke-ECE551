#include "rand_story.h"

int main(int argc, char ** argv) {
  if (argc != 3) {
    fprintf(stderr, "Error: argc!");
    exit(EXIT_FAILURE);
  }

  story * s = readTemplate(argv[2]);
  catarray_t * cate = readWords(argv[1], 0);
  subStory(s, cate);
  for (size_t i = 0; i < s->line_sz; i++) {
    printf("%s", s->line[i]);
    free(s->line[i]);
  }
  free(s->line);
  free(s);

  for (size_t i = 0; i < cate->n; i++) {
    for (size_t j = 0; j < cate->arr[i].n_words; j++) {
      free(cate->arr[i].words[j]);
    }
    if (i != cate->n - 1)
      free(cate->arr[i].name);
    free(cate->arr[i].words);
  }
  if (cate->arr != NULL) {
    free(cate->arr);
  }
  free(cate);
  return EXIT_SUCCESS;
}
