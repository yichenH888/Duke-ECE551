#include "rand_story.h"

int main(int argc, char ** argv) {
  if (argc != 2) {
    fprintf(stderr, "Error: argc!");
    exit(EXIT_FAILURE);
  }
  catarray_t * cate = readWords(argv[1], 1);
  printWords(cate);
  for (size_t i = 0; i < cate->n; i++) {
    freeCategory(&cate->arr[i]);
  }
  free(cate->arr);
  free(cate);
  return EXIT_SUCCESS;
}
