#include "rand_story.h"

story * readTemplate(const char * fileName) {
  FILE * f = fopen(fileName, "r");
  if (f == NULL) {
    fprintf(stderr, "The story template file does not exist!");
    exit(EXIT_FAILURE);
  }
  story * s = malloc(sizeof(*s));
  s->line_sz = 0;
  s->line = NULL;

  char * line = NULL;
  size_t sz = 0;
  while (getline(&line, &sz, f) >= 0) {
    s->line_sz = s->line_sz + 1;
    s->line = realloc(s->line, s->line_sz * sizeof(*s->line));
    s->line[s->line_sz - 1] = strdup(line);
    free(line);
    line = NULL;
  }
  free(line);
  if (fclose(f) != 0) {
    fprintf(stderr, "The story template file cannot be closed!");
    exit(EXIT_FAILURE);
  }
  return s;
}

char * subBlank(char * line, catarray_t * cate) {
  //Find first '_' in the line
  char * posUnderscore1 = strchr(line, '_');
  //No '_' detected in the line, the input line will be returned
  if (posUnderscore1 == NULL) {
    return line;
  }

  //Find second '_' in the line
  char * posUnderscore2 = strchr(posUnderscore1 + 1, '_');
  if (posUnderscore2 == NULL) {
    fprintf(stderr, "Missing second '_'!");
    exit(EXIT_FAILURE);
  }

  // Get Category
  size_t sizeCategory = posUnderscore2 - posUnderscore1 - 1;

  char * category = strndup(posUnderscore1 + 1, sizeCategory);
  //Get word for substitution
  const char * sub_chosen = decideWord(category, cate);

  if (cate != NULL) {  //add used word
    cate->arr[cate->n - 1].n_words++;
    cate->arr[cate->n - 1].words =
        realloc(cate->arr[cate->n - 1].words,
                cate->arr[cate->n - 1].n_words * sizeof(*cate->arr[cate->n - 1].words));
    cate->arr[cate->n - 1].words[cate->arr[cate->n - 1].n_words - 1] = strdup(sub_chosen);
  }

  free(category);

  //Size of line after substitution, including "\0"
  size_t size_afterSub = strlen(line) - sizeCategory - 2 + strlen(sub_chosen) + 1;

  //Create the line "afterSub"
  char * afterSub =
      malloc((size_afterSub + 1) * (sizeof(*afterSub)));  //Need one more space for "\0"

  size_t BeSub_SZ = posUnderscore1 - line;  //size of string before sub word
  size_t sub_chosen_SZ = strlen(sub_chosen);
  size_t AfSub_SZ =
      size_afterSub - BeSub_SZ - sub_chosen_SZ;  //size of string after sub word
  for (size_t i = 0; i < BeSub_SZ; i++) {
    *(afterSub + i) = *(line + i);
  }

  for (size_t i = 0; i < sub_chosen_SZ; i++) {
    *(afterSub + i + BeSub_SZ) = *(sub_chosen + i);
  }
  for (size_t i = 0; i < AfSub_SZ; i++) {
    *(afterSub + i + BeSub_SZ + sub_chosen_SZ) =
        *(line + BeSub_SZ + sizeCategory + 2 + i);
  }

  free(line);
  return subBlank(afterSub, cate);
}

void subStory(story * s, catarray_t * cate) {
  size_t i = 0;
  while (i < s->line_sz) {
    s->line[i] = subBlank(s->line[i], cate);
    i++;
  }
}

catarray_t * readWords(const char * fileName, int step2) {
  FILE * f = fopen(fileName, "r");
  if (f == NULL) {
    fprintf(stderr, "The 'Words' file does not exist!");
    exit(EXIT_FAILURE);
  }
  catarray_t * cate = malloc(sizeof(*cate));
  cate->n = 0;
  cate->arr = NULL;

  char * line = NULL;
  size_t sz = 0;
  while (getline(&line, &sz, f) >= 0) {
    cate = processWords(line, cate);
    free(line);
    line = NULL;
  }
  free(line);
  if (fclose(f) != 0) {
    fprintf(stderr, "The 'words' file cannot be closed!");
    exit(EXIT_FAILURE);
  }
  if (step2 == 1) {
    return cate;
  }

  cate = addUsedCat(cate);
  return cate;
}

catarray_t * processWords(char * line, catarray_t * cate) {
  //Find first ':' in the line
  char * colon = strchr(line, ':');
  if (colon == NULL) {
    fprintf(stderr, "Illegal Input: No colon found!");
    exit(EXIT_FAILURE);
  }
  char * colon2 = strchr(colon + 1, ':');
  if (colon2 != NULL) {
    fprintf(stderr, "Illegal Input: More than one colon is found!");
    exit(EXIT_FAILURE);
  }
  char * changeLine = strchr(line, '\n');
  if (changeLine == NULL) {
    fprintf(stderr, "Illegal Input: No '\n' in the end of this line");
    exit(EXIT_FAILURE);
  }

  // Analyze the name and word in the input line
  size_t name_length = colon - line;
  char * name = strndup(line, name_length);
  size_t word_length = changeLine - colon - 1;
  char * word = strndup(colon + 1, word_length);

  size_t i = 0;
  size_t index = 0;  //array index where the category exist
  int flag = 0;      //Turn to 1 when the category alreagy exist
  while (i < cate->n) {
    if (strcmp(name, cate->arr[i].name) == 0) {  //if the category already exist
      flag = 1;
      index = i;
    }
    i++;
  }

  if (flag == 0) {
    cate->n++;
    cate->arr = realloc(cate->arr, cate->n * sizeof(*cate->arr));
    cate->arr[cate->n - 1].name = name;
    cate->arr[cate->n - 1].n_words = 1;
    cate->arr[cate->n - 1].words = malloc(sizeof(*cate->arr[cate->n - 1].words));
    cate->arr[cate->n - 1].words[0] = word;
  }
  else if (flag == 1) {
    cate->arr[index].n_words++;
    cate->arr[index].words =
        realloc(cate->arr[index].words,
                cate->arr[index].n_words * sizeof(*cate->arr[index].words));
    cate->arr[index].words[cate->arr[index].n_words - 1] = word;

    free(name);
  }
  return cate;
}

//add one more line to store the used word, initialize the words: store NULL in index 0
catarray_t * addUsedCat(catarray_t * cate) {
  cate->n++;
  cate->arr = realloc(cate->arr, cate->n * sizeof(*cate->arr));
  cate->arr[cate->n - 1].name = "used";
  cate->arr[cate->n - 1].n_words = 0;
  cate->arr[cate->n - 1].words = malloc(sizeof(*cate->arr[cate->n - 1].words));
  cate->arr[cate->n - 1].words[0] = NULL;
  return cate;
}

const char * decideWord(char * category, catarray_t * cate) {
  int reference;
  if (cate == NULL) {
    return chooseWord(category, cate);
  }

  for (size_t i = 0; i < cate->n; i++) {
    if (strcmp(category, cate->arr[i].name) == 0) {  //if category match
      return chooseWord(category, cate);
    }
  }

  if (strspn(category, "0123456789") !=
      strlen(
          category)) {  //category does not match any given category, also not integer number
    fprintf(stderr, "The story template does not give corrct 'category'!");
    exit(EXIT_SUCCESS);
  }
  else {
    reference = atoi(category);  //get the integer reference
    return cate->arr[cate->n - 1].words[cate->arr[cate->n - 1].n_words - reference];
  }
}

void freeCategory(category_t * cate) {
  free(cate->name);
  for (size_t i = 0; i < cate->n_words; i++) {
    free(cate->words[i]);
  }
  free(cate->words);
}
