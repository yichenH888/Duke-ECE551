#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

char * modifyPath(char * ori, char * add) {  //modify file path
  char * temp = new char[strlen(ori) + strlen(add) + 1];
  strcpy(temp, ori);
  strcat(temp, add);

  ori = temp;
  delete[] temp;
  return ori;
}

template<class T>  //convert string to other type
T stringToNum(const string & str) {
  istringstream iss(str);
  T num;
  iss >> num;
  return num;
}

vector<string> readFile(string path) {  //read in file
  ifstream read(path);
  if (read.fail()) {
    std::cerr << "Can't open file: " << path << std::endl;
    exit(EXIT_FAILURE);
  }
  string aLine;
  vector<std::string> lines;
  while (!read.eof()) {
    std::getline(read, aLine);
    lines.push_back(aLine);
  }
  return lines;
}
