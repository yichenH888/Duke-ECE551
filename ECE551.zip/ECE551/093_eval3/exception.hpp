#include <exception>
#include <iostream>

using namespace std;
void errorMsg(const char * msg) {
  cerr << msg << endl;
  exit(EXIT_FAILURE);
}

class referenceInvalid : public exception {
 public:
  virtual const char * what() const throw() {
    return "The page that is referenced by the choice is invalid!";
  }
};

class neverReferenced : public exception {
 public:
  virtual const char * what() const throw() {
    return "This page is never referenced by other pages!";
  }
};

class noWinLose : public exception {
 public:
  virtual const char * what() const throw() { return "No Win/Lose Page in this story!"; }
};

class argcNum : public exception {
 public:
  virtual const char * what() const throw() { return "Unexpected number of input file!"; }
};
