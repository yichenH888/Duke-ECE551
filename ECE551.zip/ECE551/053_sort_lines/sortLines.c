#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//This function is used to figure out the ordering of the strings
//in qsort. You do not need to modify it.
int stringOrder(const void * vp1, const void * vp2) {
  const char * const * p1 = vp1;
  const char * const * p2 = vp2;
  return strcmp(*p1, *p2);
}
//This function will sort data (whose length is count).
void sortData(char ** data, size_t count) {
  qsort(data, count, sizeof(char *), stringOrder);
}

void pro(FILE * f) {
  char ** lines = malloc(sizeof(*lines));
  if (lines == NULL) {
    fprintf(stderr, "mem not enough!");
    exit(EXIT_FAILURE);
  }
  char * line = NULL;
  size_t char_count = 0;
  size_t line_count = 0;
  while (getline(&line, &char_count, f) >= 0) {
    lines = realloc(lines, (line_count + 1) * sizeof(*lines));
    lines[line_count] = line;
    line_count++;
    line = NULL;
  }
  //get each line from file, realloc lines every time and write line to lines
  sortData(lines, line_count);
  for (size_t i = 0; i < line_count; i++) {
    printf("%s", lines[i]);
    free(lines[i]);
  }
  free(lines);
  free(line);
}

int main(int argc, char ** argv) {
  //WRITE YOUR CODE HERE!
  if (argc == 1) {
    FILE * f = stdin;
    if (f == NULL) {
      fprintf(stderr, "Could not open file");
      return EXIT_FAILURE;
    }
    pro(f);
  }
  if (argc > 1) {
    for (size_t i = 1; i < argc; i++) {
      FILE * f = fopen(argv[i], "r");
      if (f == NULL) {
        fprintf(stderr, "Could not open file");
        return EXIT_FAILURE;
      }
      pro(f);
      if (fclose(f) != 0) {
        fprintf(stderr, "Failed to close the input file: %s!", argv[i]);
        return EXIT_FAILURE;
      }
    }
  }
  return EXIT_SUCCESS;
}
