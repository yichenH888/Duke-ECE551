#include <algorithm>
#include <cstring>
#include <iostream>
#include <stack>

#include "exception.hpp"
#include "read.hpp"

using namespace std;
class Choices {  //Store each choice
 public:
  size_t prevPage;    //store prev page number, one-to-one correspondence with choices
  string choiceText;  //store content of different choices
  size_t destPage;    //store dest page number, one-to-one correspondence with choices
  string var_choi;
  long int val_choi;
  Choices(){};  //default constructor
  Choices(const Choices & rhs) :
      prevPage(rhs.prevPage),
      choiceText(rhs.choiceText),
      destPage(rhs.destPage),
      var_choi(rhs.var_choi),
      val_choi(rhs.val_choi){};              //copy constructor
  Choices & operator=(const Choices & rhs);  //assignment operator
  ~Choices(){};                              //destructor
};

Choices & Choices::operator=(const Choices & rhs) {  //assignment operator
  if (this != &rhs) {
    prevPage = rhs.prevPage;
    choiceText = rhs.choiceText;
    destPage = rhs.destPage;
    var_choi = rhs.var_choi;
    val_choi = rhs.val_choi;
  }
  return *this;
}

class Page {  //Store each page
 private:
  size_t pageNum;  //page number
  char pageType;
  string fileName;  //store file name for this page
 public:
  vector<Choices> choicesPage;  //choices for each page
  int visited = 0;              //for DFS
  size_t prev;                  //for DFS
  vector<string> var;
  vector<long int> val;
  Page() : prev(10086){};  //default constructor
  Page(const Page & rhs) :
      pageNum(rhs.pageNum),
      pageType(rhs.pageType),
      fileName(rhs.fileName),
      choicesPage(rhs.choicesPage),
      visited(rhs.visited),
      prev(rhs.prev),
      var(rhs.var),
      val(rhs.val){};                  //copy constructor
  Page & operator=(const Page & rhs);  //assignment operator
  void setpageNum(size_t input);
  size_t getpageNum();
  void setpageType(char input);
  char getpageType();
  void setfileName(string input);
  string getfileName();
  void printPage(
      char *
          pathDirect);  //print out the content of page according to different page type
  vector<int> printPage_withVar(
      char * pathDirect,
      vector<string> variable,
      vector<long int>
          value);  //print out the content of page according to different page type (with variable)
  ~Page(){};  //destructor
};

Page & Page::operator=(const Page & rhs) {  //assignment operator
  if (this != &rhs) {
    pageNum = rhs.pageNum;
    pageType = rhs.pageType;
    fileName = rhs.fileName;
    choicesPage = rhs.choicesPage;
    visited = rhs.visited;
    prev = rhs.prev;
    var = rhs.var;
    val = rhs.val;
  }
  return *this;
}
void Page::setpageNum(size_t input) {  //set private pageNum
  pageNum = input;
}
size_t Page::getpageNum() {  //get private pageNum
  return pageNum;
}
void Page::setpageType(char input) {  //set private pageType
  pageType = input;
}
char Page::getpageType() {  //get private pageType
  return pageType;
}

void Page::setfileName(string input) {  //set private filename
  fileName = input;
}
string Page::getfileName() {  //get private fileName
  return fileName;
}
void Page::printPage(char * pathDirect) {  //print each page
  string slash = "/";
  string path = pathDirect;
  path += slash;
  path += getfileName();
  vector<string> lines = readFile(path);

  //print text of the page
  vector<string>::iterator it = lines.begin();
  while (it != lines.end()) {
    std::cout << *it << std::endl;
    it++;
  }

  if (getpageType() == 'N') {
    cout << "What would you like to do?" << endl;
    cout << endl;

    vector<Choices>::iterator itChoices = choicesPage.begin();
    size_t choiceNum = 1;

    while (itChoices != choicesPage.end()) {
      std::cout << " " << choiceNum << ". " << itChoices->choiceText << std::endl;
      choiceNum++;
      itChoices++;
    }
  }
  else if (getpageType() == 'W') {
    cout << "Congratulations! You have won. Hooray!" << endl;
  }
  else if (getpageType() == 'L') {
    cout << "Sorry, you have lost. Better luck next time!" << endl;
  }
}

vector<int> Page::printPage_withVar(char * pathDirect,
                                    vector<string> variable,
                                    vector<long int> value) {  //Print Page with Var
  string slash = "/";
  string path = pathDirect;
  path += slash;
  path += getfileName();
  vector<string> lines = readFile(path);
  vector<int> unchoices;
  //print text of the page
  vector<string>::iterator it = lines.begin();
  while (it != lines.end()) {
    std::cout << *it << std::endl;
    it++;
  }

  if (getpageType() == 'N') {
    cout << "What would you like to do?" << endl;
    cout << endl;

    vector<Choices>::iterator itChoices = choicesPage.begin();
    size_t choiceNum = 1;

    while (itChoices != choicesPage.end()) {
      int avai_noFound0 = 0;
      avai_noFound0 = count(variable.begin(), variable.end(), itChoices->var_choi) == 0 &&
                      itChoices->val_choi == 0;
      int avai_found = 0;
      for (size_t i = 0; i < variable.size(); i++) {
        if (itChoices->var_choi == variable.at(i) && itChoices->val_choi == value.at(i)) {
          avai_found = 1;
          break;
        }
      }
      int avai_empty = 0;
      avai_empty = itChoices->var_choi.empty();

      if (avai_noFound0 || avai_found || avai_empty) {
        std::cout << " " << choiceNum << ". " << itChoices->choiceText << std::endl;
      }
      else {
        std::cout << " " << choiceNum << ". "
                  << "<UNAVAILABLE>" << std::endl;
        unchoices.push_back(choiceNum);
      }

      choiceNum++;
      itChoices++;
    }
  }
  else if (getpageType() == 'W') {
    cout << "Congratulations! You have won. Hooray!" << endl;
  }
  else if (getpageType() == 'L') {
    cout << "Sorry, you have lost. Better luck next time!" << endl;
  }

  return unchoices;
}

class Story {  // Store the whole story
 private:
  vector<Page> pages;
  vector<Choices> choices;
  vector<string> variable;
  vector<long int> value;
  void assignPage(vector<std::string> lines);
  void assignChoice();
  void pathDFS();
  void assignVar(vector<std::string> lines);

 public:
  Story(){};  //default constructor
  Story(const Story & rhs) :
      pages(rhs.pages),
      choices(rhs.choices),
      variable(rhs.variable),
      value(rhs.value){};                //copy constructor
  Story & operator=(const Story & rhs);  //assignment operator
  void readStory(char * p);
  void verifyStory(char * pathDirect);
  void printStory(char * pathDirect);
  void printOwnStory(char * pathDirect);
  void printOwnStory_withVar(char * pathDirect);
  void findWinPath();
  void printWinPath(vector<size_t> winPath);
  ~Story(){};  //destructor
};
Story & Story::operator=(const Story & rhs) {  //assignment operator
  if (this != &rhs) {
    pages = rhs.pages;
    choices = rhs.choices;
    variable = rhs.variable;
    value = rhs.value;
  }
  return *this;
}

void Story::readStory(char * pathDirect) {  //read the whole story from "story.txt"
  string path = pathDirect;
  string pathAdd = "/story.txt";
  path += pathAdd;
  vector<string> lines = readFile(path);
  assignPage(lines);
  assignVar(lines);
  assignChoice();
}

void Story::assignPage(vector<std::string> lines) {  //assign each pages
  vector<string>::iterator it = lines.begin();
  while (it != lines.end()) {
    if (it->find("@") != std::string::npos) {
      Page onepage;
      size_t position = it->find("@");
      onepage.setpageNum(stringToNum<size_t>(it->substr(0, position)));
      onepage.setpageType(stringToNum<char>(it->substr(position + 1, 1)));
      onepage.setfileName(it->substr(position + 3));
      pages.push_back(onepage);
    }

    if ((count(it->begin(), it->end(), ':') > 1) && (it->find("[") == string::npos)) {
      Choices onechoice;
      size_t position1 = it->find_first_of(":");
      size_t position2 = it->find(":", position1 + 1);

      onechoice.prevPage = stringToNum<size_t>(it->substr(0, position1));
      onechoice.destPage =
          stringToNum<size_t>(it->substr(position1 + 1, position2 - position1));
      onechoice.choiceText = it->substr(position2 + 1);
      string temp_emptyString = "";
      onechoice.var_choi = temp_emptyString;
      onechoice.val_choi = 0;
      choices.push_back(onechoice);
    }

    if (count(it->begin(), it->end(), '[') > 0) {
      Choices onechoice;
      size_t positionBracket1 = it->find("[");
      size_t positionEqual = it->find("=");
      size_t positionBracket2 = it->find("]");
      size_t positionColon1 = it->find_first_of(":");
      size_t positionColon2 = it->find(":", positionColon1 + 1);
      onechoice.prevPage = stringToNum<size_t>(it->substr(0, positionBracket1));
      onechoice.var_choi = stringToNum<string>(
          it->substr(positionBracket1 + 1, positionEqual - positionBracket1 - 1));
      onechoice.val_choi = stringToNum<long int>(
          it->substr(positionEqual + 1, positionBracket2 - positionEqual));
      onechoice.destPage = stringToNum<size_t>(
          it->substr(positionColon1 + 1, positionColon2 - positionColon1 - 1));
      onechoice.choiceText = it->substr(positionColon2 + 1);
      choices.push_back(onechoice);
    }
    it++;
  }
}

void Story::assignChoice() {  //put corresponding choice to each page
  vector<Page>::iterator itPage = pages.begin();
  while (itPage != pages.end()) {
    vector<Choices>::iterator itChoice = choices.begin();
    while (itChoice != choices.end()) {
      if (itChoice->prevPage == itPage->getpageNum()) {
        itPage->choicesPage.push_back(*itChoice);
      }
      itChoice++;
    }
    itPage++;
  }
}

void Story::assignVar(vector<std::string> lines) {  //Assign each variable
  vector<string>::iterator it = lines.begin();
  while (it != lines.end()) {
    if (it->find("$") != std::string::npos) {
      size_t position1 = it->find("$");
      size_t position2 = it->find("=");

      size_t pageNum_temp = stringToNum<size_t>(it->substr(0, position1));
      string var_temp =
          stringToNum<string>(it->substr(position1 + 1, position2 - position1 - 1));
      long int val_temp = stringToNum<long int>(it->substr(position2 + 1));

      vector<Page>::iterator itPage = pages.begin();
      while (itPage != pages.end()) {
        if (itPage->getpageNum() == pageNum_temp) {
          itPage->var.push_back(var_temp);

          itPage->val.push_back(val_temp);

          break;
        }
        itPage++;
      }
    }

    it++;
  }
}

void Story::verifyStory(char * pathDirect) {  //for exception
  vector<string> temp_lines;
  temp_lines.clear();
  vector<size_t> allDestPage;
  vector<Choices>::iterator itChoice = choices.begin();
  while (itChoice != choices.end()) {
    if (itChoice->destPage > (pages.size() - 1)) {
      throw referenceInvalid();
    }
    allDestPage.push_back(itChoice->destPage);
    itChoice++;
  }

  for (size_t i = 1; i < pages.size(); i++) {
    if (count(allDestPage.begin(), allDestPage.end(), i) < 1) {
      throw neverReferenced();
    }
  }

  int haveWinLose = 0;
  vector<Page>::iterator itPage = pages.begin();
  while (itPage != pages.end()) {
    if (itPage->getpageType() == 'W' || itPage->getpageType() == 'L') {
      haveWinLose = 1;
    }
    string slash = "/";
    string path = pathDirect;
    path += slash;
    path += itPage->getfileName();
    temp_lines = readFile(path);
    itPage++;
  }
  if (haveWinLose == 0) {
    throw noWinLose();
  }
}

void Story::printStory(char * pathDirect) {  //print the whole story
  for (size_t i = 0; i < pages.size(); i++) {
    cout << "Page " << i << endl;
    cout << "==========" << endl;
    vector<Page>::iterator itPage = pages.begin();
    while (itPage != pages.end()) {
      if (itPage->getpageNum() == i) {
        //cout<<pathDirect<<endl;
        itPage->printPage(pathDirect);
      }
      itPage++;
    }
  }
}

void Story::printOwnStory(char * pathDirect) {  //print story based on input
  vector<Page>::iterator itPage = pages.begin();
  size_t destPage = 0;
  char type = 'N';
  string inputStr;
  size_t inputNum;
  while (type == 'N') {
    if (itPage == pages.end()) {
      itPage = pages.begin();
    }
    while (itPage != pages.end()) {  //print page 0
      if (itPage->getpageNum() == destPage) {
        itPage->printPage(pathDirect);
        type = itPage->getpageType();
        if (type == 'N') {
          getline(cin, inputStr);
          inputNum = stringToNum<int>(inputStr);
          while (inputNum < (size_t)1 || inputNum > itPage->choicesPage.size()) {
            cout << "That is not a valid choice, please try again" << endl;
            getline(cin, inputStr);
            inputNum = stringToNum<int>(inputStr);
          }
          destPage = itPage->choicesPage[inputNum - 1].destPage;
          break;
        }
        else if (type == 'W' || type == 'L') {
          break;
        }
      }
      itPage++;
    }
  }
}

void Story::printOwnStory_withVar(char * pathDirect) {  //print story with variable
  vector<Page>::iterator itPage = pages.begin();
  size_t destPage = 0;
  char type = 'N';
  string inputStr;
  size_t inputNum;
  while (type == 'N') {
    if (itPage == pages.end()) {
      itPage = pages.begin();
    }
    while (itPage != pages.end()) {  //print page 0
      if (itPage->getpageNum() == destPage) {
        if (itPage->var.empty() != 1) {
          for (size_t i = 0; i < itPage->var.size(); i++) {
            variable.push_back(itPage->var.at(i));
            value.push_back(itPage->val.at(i));
          }
        }
        vector<int> unChoices;
        unChoices = itPage->printPage_withVar(pathDirect, variable, value);
        type = itPage->getpageType();
        if (type == 'N') {
          getline(cin, inputStr);
          inputNum = stringToNum<int>(inputStr);
          while (inputNum < (size_t)1 || inputNum > itPage->choicesPage.size() ||
                 count(unChoices.begin(), unChoices.end(), inputNum) > 0) {
            while (inputNum < (size_t)1 || inputNum > itPage->choicesPage.size()) {
              cout << "That is not a valid choice, please try again" << endl;
              getline(cin, inputStr);
              inputNum = stringToNum<int>(inputStr);
            }

            while (count(unChoices.begin(), unChoices.end(), inputNum) > 0) {
              cout << "That choice is not available at this time, please try again"
                   << endl;  //cerr???
              getline(cin, inputStr);
              inputNum = stringToNum<int>(inputStr);
            }
          }

          destPage = itPage->choicesPage[inputNum - 1].destPage;

          break;
        }
        else if (type == 'W' || type == 'L') {
          break;
        }
      }
      itPage++;
    }
  }
}

void Story::findWinPath() {  //find win path for step 3
  pathDFS();

  int winPath_empty = 1;
  vector<size_t> winPath;
  vector<size_t> winPage;
  size_t pageTrack;
  vector<Page>::iterator itPage = pages.begin();
  while (itPage != pages.end()) {
    if (itPage->getpageType() == 'W') {
      winPage.push_back(itPage->getpageNum());
    }
    itPage++;
  }
  //track path
  for (size_t i = 0; i < winPage.size(); i++) {
    int unWin = 0;  // throw out the unWin Page
    vector<Page>::iterator itPage = pages.begin();
    while (itPage != pages.end()) {
      if (itPage->getpageNum() == winPage[i]) {
        if (itPage->prev == 10086) {
          unWin = 1;
        }
        break;
      }
      itPage++;
    }
    if (unWin == 1) {
      break;
    }
    pageTrack = winPage[i];
    winPath.push_back(pageTrack);
    while (pageTrack != 0) {
      vector<Page>::iterator itPage = pages.begin();
      while (itPage != pages.end()) {
        if (itPage->getpageNum() == pageTrack) {
          pageTrack = itPage->prev;
          winPath.push_back(pageTrack);
          break;
        }
        itPage++;
      }
    }

    printWinPath(winPath);
    winPath_empty = 0;

    winPath.clear();
  }
  if (winPath_empty == 1) {
    cout << "This story is unwinnable!" << endl;
    return;
  }
}

void Story::pathDFS() {  //apply DFS
  stack<size_t> story_DFS;
  size_t current;
  size_t neighbor;
  vector<Page>::iterator itPage = pages.begin();
  while (itPage != pages.end()) {
    if (itPage->getpageNum() == 0) {
      itPage->visited = 1;
      itPage->prev = 0;  // no meaning
      story_DFS.push(itPage->getpageNum());
      break;
    }
    itPage++;
  }

  while (story_DFS.empty() != 1) {
    current = story_DFS.top();
    story_DFS.pop();

    vector<Choices>::iterator itChoice = choices.begin();
    while (itChoice != choices.end()) {
      if (itChoice->prevPage == current) {
        neighbor = itChoice->destPage;
      }

      vector<Page>::iterator itPage = pages.begin();
      while (itPage != pages.end()) {
        if (itPage->getpageNum() == neighbor) {
          if (itPage->visited == 0) {
            itPage->visited = 1;
            itPage->prev = current;

            story_DFS.push(itPage->getpageNum());
          }
        }
        itPage++;
      }

      itChoice++;
    }
  }
}

void Story::printWinPath(vector<size_t> winPath) {  // print path for step 3
  for (int j = (int)winPath.size() - 1; j >= 0; --j) {
    cout << winPath.at(j);

    if (j != 0) {
      vector<Page>::iterator itPage = pages.begin();
      while (itPage != pages.end()) {
        if (itPage->getpageNum() == winPath.at(j)) {
          for (size_t i = 0; i < itPage->choicesPage.size(); i++) {
            if (itPage->choicesPage.at(i).destPage == winPath.at(j - 1)) {
              cout << "(" << i + 1 << "),";
              break;
            }
          }
          break;
        }
        itPage++;
      }
    }
    else if (j == 0) {
      cout << "(win)";
    }
  }
  cout << endl;
}
